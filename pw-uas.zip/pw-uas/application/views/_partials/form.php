<form method="<?= $method ?? 'post' ?>" action="<?= $action ?>">
    <h1 class="h3 mb-5"><?= $title ?? '' ?></h1>