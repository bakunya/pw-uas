<div class="row justify-content-end mt-5">
    <div class="col-12 col-md-3">
        <button type="button" class="btn btn-dark container-fluid reset">Reset</button>
    </div>
    <div class="col-12 col-md-3 mt-2 mt-md-0">
        <button type="submit" class="btn btn-primary container-fluid">Submit</button>
    </div>
</div>
</form>