<div class="container">
    <h1 class="mt-5">Home Page</h1>
    <p class="lead">Selamat Datang Pada Halaman Home</p>
    <p>Back to <a href="#">the default page by </a> firman_asharudin@amikom.ac.id.</p>
</div>